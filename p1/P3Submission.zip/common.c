/*
 * Implementations for common utilities.
 *
 */
#include <stdlib.h>
#include <stdio.h>
#include "common.h"

 // Add any function implementations here