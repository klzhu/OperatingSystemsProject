/*
 * barbershop.c:
 *      Your comments go here
 *      
 *
 *
 */
#include <stdlib.h>
#include <stdio.h>
#include "minithread.h"
#include "queue.h"
#include "synch.h"

#include <assert.h>

int main(void) {

  printf("The barbershop is open for business!\n");
  return 0;
}


