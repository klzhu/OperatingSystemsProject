/*
 * Common utilities header file
 */
#ifndef __COMMON_H__
#define __COMMON_H__


// Add any constants, function signatures, etc. here

#endif /*__COMMON_H__*/